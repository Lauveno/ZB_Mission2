import AnalogClock from './AnalogClock.js';

document.querySelectorAll('.analog-clock').forEach(AnalogClock);
