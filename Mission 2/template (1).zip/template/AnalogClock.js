const AnalogClock = $container => {
  // do something!
};

export default AnalogClock;
