import Nav from './Nav.js';
import NewsList from './NewsList.js';

export { Nav, NewsList };
